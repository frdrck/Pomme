# $Id: __init__.py,v 5c59a5bc7f48 2011/05/26 14:59:48 jon $

__version__ = "0.10"
